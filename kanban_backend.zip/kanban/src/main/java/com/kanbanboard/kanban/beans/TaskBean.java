package com.kanbanboard.kanban.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskBean {
	 private Long id;
	 private Long order_id;
	 private Long task_id;
	 private String columnId;
	 private String description;
	 private String tag;
	 private String createdBy;
	 private String createdDate;
}
