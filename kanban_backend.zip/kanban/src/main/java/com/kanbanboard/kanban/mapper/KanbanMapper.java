package com.kanbanboard.kanban.mapper;

import org.mapstruct.Mapper;

import com.kanbanboard.kanban.beans.KanbanBean;
import com.kanbanboard.kanban.entity.Kanaban;


@Mapper(componentModel = "spring")
public interface KanbanMapper {

	KanbanBean toKanbanBean(Kanaban kanban);

	Kanaban toKanban(KanbanBean kanbanBean);

}
