package com.kanbanboard.kanban.beans;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SignUpBean {

	@NotEmpty(message = "First Name required")
    private String firstName;

	@NotEmpty(message = "Last Name required")
    private String lastName;

	@NotEmpty(message = "Email Id required")
	@Email(message = "Invalid email Id")
    private String email;

	@NotEmpty(message = "Password required")
    private char[] password;

}
