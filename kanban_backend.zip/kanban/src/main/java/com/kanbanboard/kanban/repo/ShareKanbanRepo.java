package com.kanbanboard.kanban.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kanbanboard.kanban.entity.ShareKanban;

public interface ShareKanbanRepo extends JpaRepository<ShareKanban, Long> {
	@Query("SELECT i FROM ShareKanban i WHERE i.email = :email and i.kanbanId = :kanbanId ")
	List<ShareKanban> findInviteByEmailAndKanbanId(@Param("email") String email, @Param("kanbanId") Long kanbanId);
	
	@Query("SELECT i.kanbanId FROM ShareKanban i WHERE i.email = :email")
	List<Long> findInviteByEmail(@Param("email") String email);
	
	@Query("SELECT i FROM ShareKanban i WHERE i.email = :email")
	List<ShareKanban> getInviteByEmail(@Param("email") String email);
}
