package com.kanbanboard.kanban.beans;

import java.util.Date;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class KanbanBean {
    private Long id;
    @NotEmpty(message = "Data required")
    private String data;
    @NotEmpty(message = "Kanban name required")
    private String name;
    private String createdBy;
    private Date createdDate;

}
