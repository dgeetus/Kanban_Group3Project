package com.kanbanboard.kanban.beans;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShareKanbanBean {

	private Long id;

	@NotEmpty(message = "Email required")
	@Email(message = "Invalid email Id")
	private String email;

	@NotEmpty(message = "Kanban Id required")
	private Long kanbanId;

	private Long invitedBy;

	@NotEmpty(message = "Access Mode required")
	private String accessMode;

}
