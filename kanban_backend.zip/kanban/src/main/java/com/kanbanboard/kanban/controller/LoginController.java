package com.kanbanboard.kanban.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kanbanboard.kanban.beans.LoginBean;
import com.kanbanboard.kanban.beans.SignUpBean;
import com.kanbanboard.kanban.beans.UserBean;
import com.kanbanboard.kanban.security.AuthProvider;
import com.kanbanboard.kanban.svc.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/user") 
public class LoginController {

	@Autowired
	private UserService userSvc;

	@Autowired
	private AuthProvider auth;

	@PostMapping("/login")
	public ResponseEntity<UserBean> login(@RequestBody @Valid LoginBean credentialsBean) {
		UserBean userBean = userSvc.login(credentialsBean);
		userBean.setToken(auth.createToken(userBean.getEmail()));
		return ResponseEntity.ok(userBean);
	}
	
	@PostMapping("/isExist")
	public ResponseEntity<UserBean> isExist(@RequestBody @Valid LoginBean credentialsBean) {
		return ResponseEntity.ok(userSvc.getUserByEmail(credentialsBean.getEmail()));
	}

	@PostMapping("/register")
	public ResponseEntity<UserBean> register(@RequestBody @Valid SignUpBean user) {
		UserBean createdUser = userSvc.register(user);
		createdUser.setToken(auth.createToken(user.getEmail()));
		return ResponseEntity.created(URI.create("/users/" + createdUser.getId())).body(createdUser);
	}

	@GetMapping("/details")
	public ResponseEntity<UserBean> details(HttpServletRequest request) {
		return ResponseEntity.ok(userSvc.findByEmail(request.getRemoteUser()));
	}

}
