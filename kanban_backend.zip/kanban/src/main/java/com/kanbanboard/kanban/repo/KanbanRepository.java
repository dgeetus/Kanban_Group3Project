package com.kanbanboard.kanban.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kanbanboard.kanban.entity.Kanaban;


public interface KanbanRepository extends JpaRepository<Kanaban, Long> {
	@Query("SELECT u.kanbans FROM User u WHERE u.email = :email")
	List<Kanaban> findKanbansByEmail(@Param("email") String email);
	
	@Query("SELECT mm FROM Kanaban mm JOIN mm.users u WHERE mm.id = :kanbanId and u.email = :email")
    Kanaban findByKanabanIdAndUserEmail(Long kanbanId, String email);
	
    List<Kanaban> findByIdIn(List<Long> idList);

}
