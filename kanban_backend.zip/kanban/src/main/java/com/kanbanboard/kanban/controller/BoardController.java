package com.kanbanboard.kanban.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.kanbanboard.kanban.beans.KanbanBean;
import com.kanbanboard.kanban.beans.ShareKanbanBean;
import com.kanbanboard.kanban.svc.KanbanService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("api/kanban") 
public class BoardController {

	@Autowired
	private KanbanService kanbanSvc;

	@PostMapping("/update")
	public ResponseEntity<KanbanBean> update(@RequestBody @Valid KanbanBean kanbanBean,
			HttpServletRequest request) throws JsonMappingException, JsonProcessingException {
		return ResponseEntity.ok(kanbanSvc.saveKanban(kanbanBean, request.getRemoteUser()));
	}

	@PostMapping("/get")
	public ResponseEntity<KanbanBean> get(@RequestBody KanbanBean kanbanBean, HttpServletRequest request) throws JsonProcessingException {
		return ResponseEntity.ok(kanbanSvc.getKanban(kanbanBean, request.getRemoteUser()));
	}

	@GetMapping("/myboards")
	public ResponseEntity<List<KanbanBean>> myboards(HttpServletRequest request) {
		return ResponseEntity.ok(kanbanSvc.getAllKanbansByUserName(request.getRemoteUser()));
	}
	
	@GetMapping("/shared")
	public ResponseEntity<List<KanbanBean>> shared(HttpServletRequest request) {
		return ResponseEntity.ok(kanbanSvc.getSharedKanbans(request.getRemoteUser()));
	}

	@PostMapping("/invite")
	public ResponseEntity<String> invite(@RequestBody ShareKanbanBean shareKanbanBean, HttpServletRequest request) {
		kanbanSvc.invite(shareKanbanBean, request.getRemoteUser());
		return ResponseEntity.ok("inviated");
	}
}
