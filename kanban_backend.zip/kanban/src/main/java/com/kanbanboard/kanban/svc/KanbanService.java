package com.kanbanboard.kanban.svc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kanbanboard.kanban.beans.KanbanBean;
import com.kanbanboard.kanban.beans.ShareKanbanBean;
import com.kanbanboard.kanban.beans.TaskBean;
import com.kanbanboard.kanban.entity.Kanaban;
import com.kanbanboard.kanban.entity.ShareKanban;
import com.kanbanboard.kanban.entity.Task;
import com.kanbanboard.kanban.entity.User;
import com.kanbanboard.kanban.mapper.KanbanMapper;
import com.kanbanboard.kanban.mapper.ShareKanbanMapper;
import com.kanbanboard.kanban.repo.KanbanRepository;
import com.kanbanboard.kanban.repo.ShareKanbanRepo;
import com.kanbanboard.kanban.repo.TaskRepository;
import com.kanbanboard.kanban.repo.UserRepository;
import com.kanbanboard.kanban.security.AppException;

@Service
public class KanbanService {

	@Autowired
	private KanbanRepository kanbanRepository;
	@Autowired
	private TaskRepository taskRepository;
	@Autowired
	private ShareKanbanRepo shareKanbanRepo;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private KanbanMapper kanbanMapper;
	@Autowired
	private ShareKanbanMapper shareKanbanMapper;

	public KanbanBean saveKanban(KanbanBean kanbanBean, String username)
			throws JsonMappingException, JsonProcessingException {
		User user = userRepository.findByEmail(username).orElse(null);
		Kanaban kanaban = new Kanaban();
		if (kanbanBean.getId() != null) {
			kanaban = kanbanRepository.findById(kanbanBean.getId()).orElse(null);
		} else {
			kanaban.setCreatedBy(username);
			kanaban.setCreatedDate(new Date());
		}
		if (user != null && kanaban != null) {
			kanaban.setName(kanbanBean.getName());
			Set<Task> emptyTaskSet = new HashSet<>();
			kanaban.setTasks(emptyTaskSet);
			kanaban = kanbanRepository.save(kanaban);
			ObjectMapper objectMapper = new ObjectMapper();

			List<TaskBean> taskList = objectMapper.readValue(kanbanBean.getData(), new TypeReference<List<TaskBean>>() {
			});
			Map<Long, TaskBean> taskIds = taskList.stream().filter(taskBean -> taskBean.getTask_id() != null)
					.collect(Collectors.toMap(TaskBean::getTask_id, taskBean -> taskBean));
			List<Task> list = taskRepository.findAllById(taskIds.keySet());
			Map<Long, Task> taskEntities = list.stream().collect(Collectors.toMap(Task::getTask_id, taskBean -> taskBean));
			List<Long> deleteTasks = new ArrayList<>(taskRepository.findByKanbanId(kanaban.getId())
		            .stream()
		            .map(Task::getTask_id)
		            .collect(Collectors.toList()));
			for (TaskBean bean : taskList) {
				Task task = taskEntities.get(bean.getTask_id());
				if (task == null) {
					task = new Task();
				}
				task.setCreatedBy(bean.getCreatedBy());
				task.setCreatedDate(bean.getCreatedDate());
				task.setDescription(bean.getDescription());
				task.setOrder_id(bean.getOrder_id());
				task.setId(bean.getId());
				task.setColumnId(bean.getColumnId());
				task.setTag(bean.getTag());
				task.setKanban(kanaban);
				task = taskRepository.save(task);
				kanaban.getTasks().add(task);
				deleteTasks.remove(task.getTask_id());
			}
			//deleteTask
			for(Long id : deleteTasks) {
				Task deleteTask = taskRepository.getReferenceById(id);
				if (deleteTask != null) {
					kanaban.getTasks().remove(deleteTask);
					taskRepository.delete(deleteTask);
				}
			}
			
			kanaban = kanbanRepository.save(kanaban);
			user.getKanbans().add(kanaban);
			userRepository.save(user);
		}
		return kanbanMapper.toKanbanBean(kanaban);
	}

	public KanbanBean getKanban(KanbanBean kanbanBean, String username) throws JsonProcessingException {
		Kanaban kanaban = kanbanRepository.findByKanabanIdAndUserEmail(kanbanBean.getId(), username);
		KanbanBean kanbanBean2 = kanbanMapper
				.toKanbanBean(kanaban);
		ObjectMapper objectMapper = new ObjectMapper();
        String data = objectMapper.writeValueAsString(kanaban.getTasks()== null ? new ArrayList<>() : kanaban.getTasks());
        kanbanBean2.setData(data);
		return kanbanBean2;
	}

	public List<KanbanBean> getAllKanbansByUserName(String username) {
		List<ShareKanban> shareKanbans = shareKanbanRepo.getInviteByEmail(username);
		Map<Long, ShareKanban> shareKanbansMap = shareKanbans.stream()
				.collect(Collectors.toMap(bean -> bean.getKanbanId(), bean -> bean));

		User user = userRepository.findByEmail(username)
				.orElseThrow(() -> new AppException("Invalid user", HttpStatus.BAD_REQUEST));
		Set<Kanaban> kanabans = user.getKanbans();
		List<KanbanBean> kanabansBeans = kanabans.stream()
				.filter(kanban -> !shareKanbansMap.containsKey(kanban.getId())).map(kanban -> {
					return kanbanMapper.toKanbanBean(kanban);
				}).collect(Collectors.toList());
		Collections.sort(kanabansBeans, Comparator.comparing(KanbanBean::getId));
		return kanabansBeans;
	}

	public List<KanbanBean> getSharedKanbans(String username) {
		List<ShareKanban> shareKanbans = shareKanbanRepo.getInviteByEmail(username);
		Map<Long, ShareKanban> shareKanbansMap = shareKanbans.stream()
				.collect(Collectors.toMap(bean -> bean.getKanbanId(), bean -> bean));

		User user = userRepository.findByEmail(username)
				.orElseThrow(() -> new AppException("Invalid user", HttpStatus.BAD_REQUEST));
		Set<Kanaban> kanabans = user.getKanbans();
		List<KanbanBean> kanabansBeans = kanabans.stream().filter(kanban -> shareKanbansMap.containsKey(kanban.getId()))
				.map(kanban -> {
					return kanbanMapper.toKanbanBean(kanban);
				}).collect(Collectors.toList());
		Collections.sort(kanabansBeans, Comparator.comparing(KanbanBean::getId));
		return kanabansBeans;
	}

	public void invite(ShareKanbanBean shareKanbanBean, String username) {
		List<ShareKanban> ShareKanbans = shareKanbanRepo.findInviteByEmailAndKanbanId(shareKanbanBean.getEmail(),
				shareKanbanBean.getKanbanId());
		User user = userRepository.findByEmail(username).orElse(null);
		if (user == null) {
			throw new AppException("Invalid Request.", HttpStatus.BAD_REQUEST);
		}
		if (!ShareKanbans.isEmpty()) {
			throw new AppException("Invite already existed.", HttpStatus.BAD_REQUEST);
		}
		shareKanbanBean.setInvitedBy(user.getId());
		ShareKanban shareKanban = shareKanbanMapper.toInvite(shareKanbanBean);

		User existUser = userRepository.findByEmail(shareKanbanBean.getEmail()).orElse(null);
		Kanaban kanaban = kanbanRepository.findById(shareKanbanBean.getKanbanId()).orElse(null);
		if (kanaban != null && existUser != null) {
			existUser.getKanbans().add(kanaban);
			userRepository.save(user);
		}

		shareKanbanRepo.save(shareKanban);
	}

}
