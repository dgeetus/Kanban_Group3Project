package com.kanbanboard.kanban.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.kanbanboard.kanban.beans.SignUpBean;
import com.kanbanboard.kanban.beans.UserBean;
import com.kanbanboard.kanban.entity.User;


@Mapper(componentModel = "spring")
public interface UserMapper {

	UserBean toUserBean(User user);

	@Mapping(target = "password", ignore = true)
	User signUpToUser(SignUpBean signUpBean);

}
