package com.kanbanboard.kanban.svc;

import java.nio.CharBuffer;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kanbanboard.kanban.beans.LoginBean;
import com.kanbanboard.kanban.beans.SignUpBean;
import com.kanbanboard.kanban.beans.UserBean;
import com.kanbanboard.kanban.entity.Kanaban;
import com.kanbanboard.kanban.entity.ShareKanban;
import com.kanbanboard.kanban.entity.User;
import com.kanbanboard.kanban.mapper.UserMapper;
import com.kanbanboard.kanban.repo.KanbanRepository;
import com.kanbanboard.kanban.repo.ShareKanbanRepo;
import com.kanbanboard.kanban.repo.UserRepository;
import com.kanbanboard.kanban.security.AppException;



@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private KanbanRepository kanbanRepository;
	
	@Autowired
	private ShareKanbanRepo shareKanbanRepo;

	@Autowired
	private UserMapper userMapper;

	public UserBean login(LoginBean credentialsBean) {
		User user = userRepository.findByEmail(credentialsBean.getEmail())
				.orElseThrow(() -> new AppException("Invalid email or password", HttpStatus.BAD_REQUEST));

		if (passwordEncoder.matches(CharBuffer.wrap(credentialsBean.getPassword()), user.getPassword())) {
			return userMapper.toUserBean(user);
		}
		throw new AppException("Invalid email or password", HttpStatus.BAD_REQUEST);
	}

	public UserBean getUserByEmail(String email) {
		User user = userRepository.findByEmail(email)
				.orElseThrow(() -> new AppException("user not exist", HttpStatus.BAD_REQUEST));
		if (user != null) {
			return userMapper.toUserBean(user);
		}
		return null;
	}

	public UserBean register(SignUpBean userBean) {
		Optional<User> optionalUser = userRepository.findByEmail(userBean.getEmail());

		if (optionalUser.isPresent()) {
			throw new AppException("Login already exists", HttpStatus.BAD_REQUEST);
		}

		User user = userMapper.signUpToUser(userBean);
		user.setPassword(passwordEncoder.encode(CharBuffer.wrap(userBean.getPassword())));

		User savedUser = userRepository.save(user);

		List<ShareKanban> shareKanbans = shareKanbanRepo.getInviteByEmail(userBean.getEmail());
		if (!shareKanbans.isEmpty()) {
			for(ShareKanban shareKanban : shareKanbans) {
				Kanaban kanaban = kanbanRepository.findById(shareKanban.getKanbanId()).orElse(null);
				if (savedUser != null && kanaban != null) {
					savedUser.getKanbans().add(kanaban);
					userRepository.save(savedUser);
				}
			}
		}

		return userMapper.toUserBean(savedUser);
	}

	public UserBean findByEmail(String login) {
		User user = userRepository.findByEmail(login)
				.orElseThrow(() -> new AppException("Unknown user", HttpStatus.NOT_FOUND));
		return userMapper.toUserBean(user);
	}

}
