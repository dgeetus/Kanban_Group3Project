package com.kanbanboard.kanban.mapper;

import org.mapstruct.Mapper;

import com.kanbanboard.kanban.beans.ShareKanbanBean;
import com.kanbanboard.kanban.entity.ShareKanban;


@Mapper(componentModel = "spring")
public interface ShareKanbanMapper {

	ShareKanbanBean toInviteDto(ShareKanban shareKanban);

	ShareKanban toInvite(ShareKanbanBean shareKanbanDto);

}
