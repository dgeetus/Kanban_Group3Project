package com.kanbanboard.kanban.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kanbanboard.kanban.entity.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByKanbanId(Long kanbanId);

}
