import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginForm from './pages/Login';
import Dashboard from './pages/Dashboard';
import Registration from './pages/Registration';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/signup" element={<Registration />} />
        <Route path="/logout" element={<LoginForm />} />
        <Route path="/" element={<LoginForm />}>
        <Route path="*" element={<LoginForm />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
