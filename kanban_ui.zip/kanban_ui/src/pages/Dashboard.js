import 'bootstrap/dist/css/bootstrap.min.css';
import "../style.css"
import Header from './Header';
import Footer from './Footer';
import Kanbans from './Kanbans';
import { useState } from "react";
import KanbanBoard from '../kanban/KanbanBoard';


export default function Dashboard() {
  const [editId, setEditId] = useState(null);
  const [viewMode, setViewMode] = useState(false);
  const [showGrid, setShowGrid] = useState('Dashboard');
  return (
    <>
      <main className="main-content">
        <Header />
        {showGrid == 'Kanban' ? <KanbanBoard editId={editId} viewMode={viewMode} /> : <Kanbans setShowGrid={setShowGrid} setEditId={setEditId} setViewMode={setViewMode} />
        }
      </main>
    </>

  );
}