import { request } from '../helpers/axios_helper';
import { useEffect, useState } from "react";
import { BsFillPencilFill, BsShareFill } from "react-icons/bs";
import { Alert, Button, Card, Container, FloatingLabel, Form, Modal, Tab, Table, Tabs } from 'react-bootstrap';
import InviteModel from './InviteModel.js';
import { IoOpenOutline } from 'react-icons/io5/index.js';
import { GrView } from "react-icons/gr";


export default function Kanbans({ setEditId, setShowGrid, setViewMode }) {
  const [errMsg, setErrMsg] = useState('');
  const [validated, setValidated] = useState(false);
  const [name, setName] = useState('');
  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false);
    setValidated(true);
  }
  const handleShow = () => {
    setShow(true);
    setName('');
    setValidated(false);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    if (form.checkValidity() === true) {
      updateMap();
    }
    setValidated(true);

  }
  function updateMap() {
    request(
      "POST",
      "/api/kanban/update",
      {
        name: name,
        data: "[]",
      }).then(
        (response) => {
          setErrMsg('')
          setShow(false)
          setValidated(false);
          loadKanbans();
          setEditId(response.data.id);
          setShowGrid('Kanban');
        }).catch(
          (err) => {
            console.log(err)
            if (!err?.response) {
              setErrMsg('No Server Response');
            } else {
              setErrMsg('Something went wrong..!');
            }
          }
        );
  }
  const [data, setData] = useState(null);
  const [sharedata, setSharedata] = useState(null);
  useEffect(() => {
    loadKanbans();
    loadShareKanbans();
  }, [])

  function loadKanbans() {
    localStorage.setItem('editMapId', null);
    request(
      "GET",
      "/api/kanban/myboards",
      {
      }).then(
        (response) => {
          setData(response.data)
        }).catch(
          (err) => {
            console.log(err)
          }
        );
  }
  function loadShareKanbans() {
    localStorage.setItem('editMapId', null);
    request(
      "GET",
      "/api/kanban/shared",
      {
      }).then(
        (response) => {
          setSharedata(response.data)
        }).catch(
          (err) => {
            console.log(err)
          }
        );
  }

  return (
    <>
      <Container fluid className="main-content-container px-4">
        <div className="page-header py-4 no-gutters row">
          <div className="text-sm-left mb-5 text-md-left mb-sm-0 col-12">
            <Card className="card_main">
              <Card.Body>
                <h4 className='p-2'>Create New Board</h4>
                <Card style={{ width: '50%' }}>
                  <Card.Body>
                    {errMsg != '' ?
                      <Alert key="danger" variant="danger">
                        {errMsg}
                      </Alert>
                      : ''}
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" >
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                          type="text"
                          autoFocus required
                          onChange={(e) => setName(e.target.value)}
                          value={name}
                        />
                      </Form.Group>
                      <Modal.Footer className='mt-3'>
                        <Button variant="success" type="submit">
                          Create
                        </Button>
                      </Modal.Footer>
                    </Form>
                  </Card.Body>
                </Card>
                <h4 className='p-2 pt-3 border-top my-5'>My Boards</h4>
                <Table striped bordered hover >
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data !== null && data.length > 0 ? data.map((item) => (
                      <tr key={item.id}>
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>
                          <a onClick={() => {
                            setEditId(item.id);
                            setShowGrid('Kanban');
                            setViewMode(false);
                          }
                          } className="alert-link pr-2 primary" style={{ cursor: 'pointer' }}><IoOpenOutline className="icons_cc" /></a> |
                          <a onClick={() => {
                            setEditId(item.id);
                            setShowGrid('Kanban');
                            setViewMode(true);
                          }
                          } className="alert-link pr-2 primary" style={{ cursor: 'pointer' }}><GrView className="icons_cc" /></a>

                        </td>
                      </tr>
                    )) :
                      <tr>
                        <td colSpan={4}>No Records</td>
                      </tr>
                    }
                  </tbody>
                </Table>
                <h4 className='p-2 pt-3 border-top my-5'>Shared Boards</h4>
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sharedata !== null && sharedata.length > 0 ? sharedata.map((item) => (
                      <tr key={item.id}>
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>
                          <a onClick={() => {
                            setEditId(item.id);
                            setShowGrid('Kanban');
                            setViewMode(false);
                          }
                          } className="alert-link pr-2 primary" style={{ cursor: 'pointer' }}><IoOpenOutline className="icons_cc" /></a> |
                          <a onClick={() => {
                            setEditId(item.id);
                            setShowGrid('Kanban');
                            setViewMode(true);
                          }
                          } className="alert-link pr-2 primary" style={{ cursor: 'pointer' }}><GrView className="icons_cc" /></a>

                        </td>
                      </tr>
                    )) :
                      <tr>
                        <td colSpan={4}>No Records</td>
                      </tr>
                    }
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          </div>
        </div>
      </Container>
    </>

  );
}