import { useEffect, useState } from "react";
import { Alert, Button, Card, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../style.css"
import { request, setAuthHeader, setUserFullName } from '../helpers/axios_helper';
import { Link, Navigate } from "react-router-dom";



export default function LoginForm() {

    const [validated, setValidated] = useState(false);
    const [user, setUser] = useState('');
    const [pwd, setPwd] = useState('');
    const [errMsg, setErrMsg] = useState('');
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        setAuthHeader(null);
        setUserFullName(null);
    }, [])

    useEffect(() => {
        setErrMsg('');
    }, [user, pwd])

    const handleSubmit = async (e) => {
        e.preventDefault();
        const form = e.currentTarget;
        if (form.checkValidity() === true) {
            request(
                "POST",
                "/user/login",
                {
                    email: user,
                    password: pwd
                }).then(
                    (response) => {
                        console.log("login data")
                        console.log(response)
                        setAuthHeader(response.data.token);
                        setUserFullName(response.data.firstName + " " + response.data.lastName);
                        setUser('');
                        setPwd('');
                        setSuccess(true);
                        setErrMsg('')
                    }).catch(
                        (err) => {
                            setAuthHeader(null);
                            setUserFullName(null);
                            console.log(err)
                            if (!err?.response) {
                                setErrMsg('No Server Response');
                            } else if (err.response?.status === 400) {
                                setErrMsg('Invalid Email or Password');
                            } else if (err.response?.status === 401) {
                                setErrMsg('Unauthorized');
                            } else {
                                setErrMsg('Login Failed');
                            }
                        }
                    );
        }
        setValidated(true);
    }
    if (success) {
        return <Navigate to="/dashboard" replace />;
    }
    return (
        <Container className="login_card justify-content-md-center back div-center">

<Card>
                <Card.Header as="h5">Sign In</Card.Header>
            {errMsg != '' ?
                <Alert key="danger" variant="danger">
                    {errMsg}
                </Alert>
                : ''}
            <Card.Body>
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
                <Form.Group className="mb-3 isInvalid" controlId="email">
                <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" required
                        autoComplete="off"
                        onChange={(e) => setUser(e.target.value)}
                        value={user}
                    />
                    <Form.Control.Feedback type="invalid">
                        Please provide a valid Email.
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-3" controlId="password">
                <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" required
                        onChange={(e) => setPwd(e.target.value)}
                        value={pwd} />
                    <Form.Control.Feedback type="invalid">
                        Please provide password.
                    </Form.Control.Feedback>
                </Form.Group>
               <div className="d-grid gap-2">
                    <Button variant="primary" type="submit">
                        Submit
                    </Button>
                    <Row>
                        <Col><a href="/signup" className="d-flex justify-content-end pt-2">Register</a></Col>
                    </Row>
                </div>
            </Form>
            </Card.Body>
            </Card>
        </Container>
    )
}