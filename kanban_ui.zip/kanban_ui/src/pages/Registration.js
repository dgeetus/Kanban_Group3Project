import { useEffect, useState } from "react";
import { Alert, Button, Card, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { request, setAuthHeader, setUserFullName } from '../helpers/axios_helper';
import { Navigate } from "react-router-dom";



export default function Registration() {

    const [validated, setValidated] = useState(false);
    const [user, setUser] = useState('');
    const [pwd, setPwd] = useState('');
    const [fname, setFname] = useState('');
    const [lname, setLname] = useState('');
    const [errMsg, setErrMsg] = useState('');
    const [success, setSuccess] = useState(false);

    useEffect(() => {
        setAuthHeader(null);
        setUserFullName(null);
    }, [])

    useEffect(() => {
        setErrMsg('');
    }, [user, pwd, fname, lname])

    const handleSubmit = async (e) => {
        e.preventDefault();
        const form = e.currentTarget;
        if (form.checkValidity() === true) {
            request(
                "POST",
                "/user/register",
                {
                    email: user,
                    password: pwd,
                    firstName: fname,
                    lastName: lname,
                }).then(
                    (response) => {
                        console.log(response)
                        setAuthHeader(response.data.token);
                        setUserFullName(null);
                        setUser('');
                        setPwd('');
                        setSuccess(true);
                        setErrMsg('')
                    }).catch(
                        (err) => {
                            setAuthHeader(null);
                            setUserFullName(null);
                            console.log(err)
                            if (!err?.response) {
                                setErrMsg('No Server Response');
                            } else if (err.response?.status === 400) {
                                if (err.response?.data?.message) {
                                    setErrMsg(err.response?.data?.message);
                                } else {
                                    setErrMsg('Invalid Data');
                                }
                            } else if (err.response?.status === 401) {
                                setErrMsg('Unauthorized');
                            } else {
                                setErrMsg('Login Failed');
                            }
                        }
                    );
        }
        setValidated(true);
    }
    if (success) {
        return <Navigate to="/" replace />;
    }
    return (
        <Container className="justify-content-md-center back div-center">
            <Card>
                <Card.Header as="h5">Sign Up</Card.Header>
                {errMsg != '' ?
                    <Alert key="danger" variant="danger">
                        {errMsg}
                    </Alert>
                    : ''}
                <Card.Body>
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                        
                            <Form.Group as={Col} className="mb-3 isInvalid" controlId="fname">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control type="text" placeholder="" required
                                    autoComplete="off"
                                    onChange={(e) => setFname(e.target.value)}
                                    value={fname}
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a valid First Name.
                                </Form.Control.Feedback>

                            </Form.Group>
                            <Form.Group as={Col} className="mb-3 isInvalid" controlId="lname">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control type="text" placeholder="" required
                                    autoComplete="off"
                                    onChange={(e) => setLname(e.target.value)}
                                    value={lname}
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a valid Last Name.
                                </Form.Control.Feedback>
                            </Form.Group>
                        
                        <Form.Group className="mb-3 isInvalid" controlId="email">
                            <Form.Label>Email Address</Form.Label>
                            <Form.Control type="email" placeholder="" required
                                autoComplete="off"
                                onChange={(e) => setUser(e.target.value)}
                                value={user}
                            />
                            <Form.Control.Feedback type="invalid">
                                Please provide a valid Email.
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="password">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="" required
                                onChange={(e) => setPwd(e.target.value)}
                                value={pwd} />
                            <Form.Control.Feedback type="invalid">
                                Please provide password.
                            </Form.Control.Feedback>
                        </Form.Group>
                        <div className="d-grid gap-2">
                            <Button variant="primary" type="submit">
                                REGISTER
                            </Button>
                            <Row>
                                <Col><a href="/" className="d-flex justify-content-end pt-2">Sign in</a></Col>
                            </Row>
                        </div>
                    </Form>
                </Card.Body>
            </Card>
        </Container>
    )
}