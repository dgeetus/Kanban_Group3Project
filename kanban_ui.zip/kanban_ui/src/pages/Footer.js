import { Container, Row } from 'react-bootstrap';

export default function Footer() {
  return (
    <footer className="container-fluid bg-dark text-light py-3">
      <div className="row">
        <div className="col">
          Copyright © 2023 Kanban
        </div>
        <div className="col text-end">
          Terms of Use
        </div>
      </div>
    </footer>

  );
}