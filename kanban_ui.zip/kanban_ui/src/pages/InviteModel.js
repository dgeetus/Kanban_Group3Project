import { useState } from 'react';
import { Modal, Form, Button, Alert, FloatingLabel } from 'react-bootstrap';
import { request } from '../helpers/axios_helper';

export default function InviteModel({ name, inviteId, inviteMode, setInviteModel }) {
  const [invError, setInvError] = useState('');
  const [showModle, setShowModle] = useState(inviteMode);
  const [validated, setValidated] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');

  const handleModelClose = () => {
    setShowModle(false);
    setInviteModel(false);
    clean();
  };
  function clean() {
    setInviteEmail('');
    setValidated(false);
    setInvError('');
    setInviteModel(false);
  }

  const handleShare = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (form.checkValidity() === true) {
      request(
        "POST",
        "/api/kanban/invite",
        {
          kanbanId: inviteId,
          accessMode: 'Edit',
          email: inviteEmail,
        }).then(
          (response) => {
            console.log(response);
            clean();
          }).catch(
            (err) => {
              console.log(err);
              if (!err?.response) {
                setInvError('No Server Response');
              } else if (err.response?.status === 400) {
                if (err.response?.data?.message) {
                  setInvError(err.response?.data?.message);
                } else {
                  setInvError('Invalid Data');
                }
              } else if (err.response?.status === 401) {
                setInvError('Unauthorized');
              } else {
                setInvError('Something went wrong..!');
              }
            }
          );
    }
    setValidated(true);
  }
  return (
    <>
      <Modal show={showModle} onHide={handleModelClose}>
        <Modal.Header closeButton>
          <Modal.Title>Share Kanban board <b>{name}</b></Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {invError != '' ?
            <Alert key="danger" variant="danger">
              {invError}
            </Alert>
            : ''}
            <Form noValidate validated={validated} onSubmit={handleShare}>
              <Form.Group className="mb-3" >
              <Form.Label>Email Address</Form.Label>
                <Form.Control
                  type="email"
                  autoFocus required
                  onChange={(e) => setInviteEmail(e.target.value)}
                  value={inviteEmail}
                />
                <Form.Control.Feedback type="invalid">
                  Please provide a valid Email.
                </Form.Control.Feedback>
              </Form.Group>
              <Modal.Footer className='mt-3'>
                <Button variant="success" type="submit">
                  Share
                </Button>
              </Modal.Footer>
            </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}