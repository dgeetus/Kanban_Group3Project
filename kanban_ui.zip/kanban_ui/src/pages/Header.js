import React from 'react';
// import { Navbar, Nav } from 'react-bootstrap';
import { request, isLoggedIn, setUserFullName } from '../helpers/axios_helper';
import { Navigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { BsFillKanbanFill } from 'react-icons/bs';

export default function Header() {
  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [login, setLogin] = React.useState(true);
  React.useEffect(() => {
    if (isLoggedIn() == true) {
      request(
        "GET",
        "/user/details",
        null).then(
          (response) => {
            console.log(response)
            setEmail(response.data.email);
            setName(response.data.firstName + " " + response.data.lastName)
            setUserFullName(response.data.firstName + " " + response.data.lastName);
            setLogin(true)
          }).catch(
            (err) => {
              setLogin(false)
            }
          );
    } else {
      setLogin(false)
    }
  }, [])
  if (!login) {
    return <Navigate to="/login" replace />;
  }
  return (
    <>
       <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
      <Container fluid className='text-white'>
        <Navbar.Brand href="/dashboard"><BsFillKanbanFill /> KanbanBoard</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
          </Nav>
          <Nav>
            <Nav.Link href="#deets">{name}</Nav.Link>
            <Nav.Link href="#deets">{email}</Nav.Link>
            <Nav.Link className='logout' eventKey={2} href="/">
              logout
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  </>
  );
}