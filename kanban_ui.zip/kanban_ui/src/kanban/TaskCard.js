import { useState } from "react";
import TrashIcon from "../icons/TrashIcon";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import React from 'react';
import { BsFillCalendar2Fill, BsFillPersonFill } from "react-icons/bs";
import { Alert, Badge, Button, Card, CardGroup, CloseButton, Col, Container, Form, Modal, Row, Table } from 'react-bootstrap';


function TaskCard({ task, deleteTask, updateTask, editModeflg, setNewlyAddedTaskId, showEditModel, viewMode }) {
  const getTaskClass = (taskType) => {
    switch (taskType) {
      case 'doing':
        return 'ip_card';
      case 'todo':
        return 'todo_card';
      case 'done':
        return 'done_card';
      default:
        return '';
    }
  };
  const [mouseIsOver, setMouseIsOver] = useState(false);
  const [editMode, setEditMode] = useState(editModeflg);
  const [typemode, setTypemode] = useState(getTaskClass(task.columnId));
  

  const { setNodeRef, attributes, listeners, transform, transition, isDragging,
  } = useSortable({
    id: task.id,
    data: {
      type: "Task",
      task,
    },
    disabled: viewMode,
  });
  const getTagCol = (taskType) => {
    switch (taskType) {
      case 'Low':
        return 'primary';
      case 'Medium':
        return 'success';
      case 'High':
        return 'danger';
      default:
        return '';
    }
  };
  const style = {
    transition,
    transform: CSS.Transform.toString(transform),
  };
  const toggleEditMode = () => {
    setEditMode((prev) => !prev);
    setMouseIsOver(false);
    setNewlyAddedTaskId(null)
  };

  const oncardclick = () => {
    if(!viewMode){
      showEditModel(task);
    }
  };

  if (isDragging) {
    <Card
    onClick={oncardclick}
    ref={setNodeRef} {...attributes}  {...listeners}  border={typemode} className={`mb-3`} >
    <Card.Body>
    <div className="text-muted text-end"> <small className="text-muted text-end">{task.createdBy}</small> </div>
      <blockquote className="blockquote mb-0">
        <p>
          {task.description}
        </p>
        <Badge bg={getTagCol(task.tag)}>{task.tag}</Badge>
      </blockquote>
      <div className="text-muted text-end"> <small className="text-muted text-end">{task.createdDate}</small> </div>
    </Card.Body>
  </Card>
  }

  return (
    <Card
      onClick={oncardclick}
      ref={setNodeRef} {...attributes}  {...listeners}  border={typemode} className={`mb-3  ${typemode}`} >
      <Card.Body>
      <div className="text-muted text-end"> <small className="text-muted text-end">{task.createdBy}</small> </div>
        <blockquote className="blockquote mb-0">
          <p>
            {task.description}
          </p>
          <Badge bg={getTagCol(task.tag)}>{task.tag}</Badge>
        </blockquote>
        <div className="text-muted text-end"> <BsFillCalendar2Fill style={{paddingRight: '0.3rem'}} /><small className="text-muted text-end">{task.createdDate}</small> </div>
      </Card.Body>
    </Card>
  );
}

export default TaskCard;
