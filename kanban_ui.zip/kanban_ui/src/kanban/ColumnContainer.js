import { SortableContext, useSortable } from "@dnd-kit/sortable";
import { useMemo } from "react";
import PlusIcon from "../icons/PlusIcon";
import TaskCard from "./TaskCard";
import React from 'react';
import { Alert, Button, Card, CardGroup, CloseButton, Col, Container, Form, Modal, Row, Table } from 'react-bootstrap';
import { IoAddCircle } from "react-icons/io5";

function ColumnContainer({ column, createTask, tasks, updateTask, editTaskId, setNewlyAddedTaskId, showEditModel, viewMode }) {
  const getTaskClass = (taskType) => {
    switch (taskType) {
      case 'doing':
        return 'warning';
      case 'todo':
        return 'primary';
      case 'done':
        return 'success';
      default:
        return '';
    }
  };
  const tasksIds = useMemo(() => {
    return tasks.map((task) => task.id);
  }, [tasks]);
  const { setNodeRef, attributes, listeners, transition } = useSortable({
    id: column.id,
    data: {
      type: "Column",
      column,
    },
    disabled: viewMode,
  });
  console.log(attributes)

  return (
      <Card  ref={setNodeRef}>
    <Card.Body  {...attributes}
        {...listeners}>
      <Card.Header className="mb-3 d-flex align-items-center justify-content-center" >
        <h5>{column.title}</h5>
      </Card.Header>
        <SortableContext items={tasksIds}>
          {tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              updateTask={updateTask}
              editModeflg={editTaskId == task.id}
              setNewlyAddedTaskId={setNewlyAddedTaskId}
              showEditModel={showEditModel}
              viewMode={viewMode}
            />
          ))}
        </SortableContext>
        </Card.Body>
         
          </Card>
  );
}

export default ColumnContainer;
