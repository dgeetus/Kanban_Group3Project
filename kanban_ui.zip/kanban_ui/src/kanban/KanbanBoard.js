import React, { useEffect } from 'react';
import "../kanban.css"
import { useMemo, useState } from "react";
import ColumnContainer from "./ColumnContainer";
import { DndContext, DragOverlay, PointerSensor, useSensor, useSensors, } from "@dnd-kit/core";
import { SortableContext, arrayMove } from "@dnd-kit/sortable";
import { createPortal } from "react-dom";
import TaskCard from "./TaskCard";
import { request, getUserFullName } from '../helpers/axios_helper';
import { Alert, Button, Card, CardGroup, CloseButton, Col, Container, FloatingLabel, Form, Modal, Row, Table } from 'react-bootstrap';
import { BsFillShareFill, BsSave } from 'react-icons/bs';
import { IoIosAddCircleOutline } from "react-icons/io";
import { IoAddSharp } from 'react-icons/io5';
import InviteModel from '../pages/InviteModel';



const defaultCols = [
  {
    id: "todo",
    title: "To Do",
  },
  {
    id: "doing",
    title: "In Progress",
  },
  {
    id: "done",
    title: "Done",
  },
];

const defaultTasks = [

];

function KanbanBoard({ editId, viewMode }) {

  const [columns, setColumns] = useState(defaultCols);
  const columnsId = useMemo(() => columns.map((col) => col.id), [columns]);
  const [tasks, setTasks] = useState([]);
  const [activeTask, setActiveTask] = useState(null);
  const [newlyAddedTaskId, setNewlyAddedTaskId] = useState(0);
  const [activeColumn, setActiveColumn] = useState(null);
  const [kanbanId, setKanbanId] = useState(null);
  const [kanbanName, setKanbanName] = useState(null);
  const [showNewTask, setShowNewTask] = useState(false);
  const [description, setDescription] = useState('');
  const [validatedNew, setValidatedNew] = useState(false);
  const [selectedValue, setSelectedValue] = useState('todo');
  const [selectedTagValue, setSelectedTagValue] = useState('Low');

  const [showNewTask2, setShowNewTask2] = useState(false);
  const [description2, setDescription2] = useState('');
  const [validatedNew2, setValidatedNew2] = useState(false);
  const [selectedValue2, setSelectedValue2] = useState('todo');
  const [selectedTagValue2, setSelectedTagValue2] = useState('Low');
  const [editTaskId, setEditTaskId] = useState(null);

  const [showAlert, setShowAlert] = useState(false);
  const [showAtleastAlert, setShowAtleastAlert] = useState(false);

  const [inviteMode, setInviteModel] = useState(false);
  const [inviteName, setInviteName] = useState(null);
  const [inviteBoardId, setInviteBoardId] = useState(null);




  const handleSelectChange = (e) => {
    setSelectedValue(e.target.value);
  };
  const handleTagSelectChange = (e) => {
    setSelectedTagValue(e.target.value);
  };
  const [errMsg, setErrMsg] = useState('');
  const handleNewModelClose = () => {
    setShowNewTask(false);
    setValidatedNew(true);
  }
  const showNewTaskModel = () => {
    setShowNewTask(true);
    setDescription('');
    setSelectedTagValue('Low');
    setSelectedValue('todo');
    setValidatedNew(false);
  };


  const handleNewSubmit = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    if (form.checkValidity() === true) {
      createTask1(selectedValue, selectedTagValue, description)
      setShowNewTask(false);
    }
    setValidatedNew(true);
  }

  const handleSelectChange2 = (e) => {
    setSelectedValue2(e.target.value);
  };
  const handleTagSelectChange2 = (e) => {
    setSelectedTagValue2(e.target.value);
  };
  const handleNewModelClose2 = () => {
    setShowNewTask2(false);
    setValidatedNew2(true);
  }
  const showEditModel = (task) => {
    setDescription2(task.description);
    setSelectedTagValue2(task.tag);
    setSelectedValue2(task.columnId);
    setValidatedNew2(false);
    setEditTaskId(task.id)
    setShowNewTask2(true);
  };

  const handleNewSubmit2 = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    if (form.checkValidity() === true) {
      updateTask(editTaskId, description2, selectedTagValue2)
      setShowNewTask2(false);
    }
    setValidatedNew2(true);
  }

  useEffect(() => {
    loadKanban(editId);
  }, [])

  function loadKanban(editId) {
    request(
      "POST",
      "api/kanban/get",
      {
        id: editId,
      }).then(
        (response) => {
          setTasks(JSON.parse(response.data.data));
          setKanbanId(response.data.id);
          setKanbanName(response.data.name);
          console.log(JSON.parse(response.data.data));
        }).catch(
          (err) => {
            console.log(err)
          }
        );
  }

  function saveKanban() {
    if(tasks.length < 1){
      showAtleastAlertFun();
      return;
    }
    console.log(tasks);
    request(
      "POST",
      "/api/kanban/update",
      {
        name: kanbanName,
        data: JSON.stringify(tasks),
        id: kanbanId,
      }).then(
        (response) => {
          console.log("Kanban data saved...")
          console.log(response);
          loadKanban(editId);
          showalert();
        }).catch(
          (err) => {
            console.log(err)
          }
        );
  }

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 10,
      },
    })
  );
  useEffect(() => {
    console.log('Tasks after initial render:', tasks);
  }, [tasks]);
  function showalert(){
    setShowAlert(true)
    const timer = setTimeout(() => {
      setShowAlert(false);
    }, 2000);
    return () => {
      clearTimeout(timer);
    };
  }

  function showAtleastAlertFun(){
    setShowAtleastAlert(true)
    const timer = setTimeout(() => {
      setShowAtleastAlert(false);
    }, 5000);
    return () => {
      clearTimeout(timer);
    };
  }
  return (
    <DndContext sensors={sensors} onDragStart={onDragStart} onDragEnd={onDragEnd} onDragOver={onDragOver}  >
      <Container className="mt-5" style={{ maxWidth: '80%' }}>
      <div>
      {showAlert && (
         <Alert key='success' variant='success' onClose={() => setShowAlert(false)} dismissible>
         Your Kanban board has been saved successfully.
       </Alert>
      )}
       {showAtleastAlert && (
         <Alert key='danger' variant='danger' onClose={() => setShowAtleastAlert(false)} dismissible>
         Please add at least one task before saving the board.
       </Alert>
      )}
    </div>
        <Card>
          <Card.Header style={{ border: 'none', marginRight:'1rem' }}  className="d-flex justify-content-between align-items-center p-4"><h3>{kanbanName} {viewMode ? ' (View Mode)' : ''} </h3>
          {!viewMode ?  <div className="text-end">
          <Button variant="info mr-5" style={{marginRight:'1rem'}} onClick={showNewTaskModel}>
            <IoAddSharp  /> New Task
              </Button>
            <Button variant="success mr-5" onClick={saveKanban} style={{marginRight:'1rem'}}>
            <BsSave /> Save
            </Button>  
              <Button variant="warning" onClick={() => {
                                  setInviteModel(true);
                                  setInviteName(kanbanName);
                                  setInviteBoardId(editId);
                                }
                                }>
            <BsFillShareFill /> Share
              </Button>
            </div> : '' }
          </Card.Header>
          <Card.Body>
            <CardGroup>
              <SortableContext items={columnsId}>
                {columns.map((col) => (
                  <ColumnContainer
                    key={col.id}
                    column={col}
                    createTask={createTask}
                    updateTask={updateTask}
                    tasks={tasks.filter((task) => task.columnId === col.id)}
                    editTaskId={newlyAddedTaskId}
                    setNewlyAddedTaskId={setNewlyAddedTaskId}
                    showEditModel={showEditModel}
                    viewMode={viewMode}
                  />
                ))}
              </SortableContext>
            </CardGroup>
          </Card.Body>
        </Card>
        <Modal show={showNewTask} onHide={handleNewModelClose}>
          <Modal.Header closeButton>
            <Modal.Title>New Task</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {errMsg != '' ?
              <Alert key="danger" variant="danger">
                {errMsg}
              </Alert>
              : ''}
            <Form noValidate validated={validatedNew} onSubmit={handleNewSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Task Type</Form.Label>
                <Form.Select value={selectedValue} onChange={handleSelectChange}>
                  <option value="todo">To Do</option>
                  <option value="doing">In Progress</option>
                  <option value="done">Done</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Priority </Form.Label>
                <Form.Select value={selectedTagValue} onChange={handleTagSelectChange}>
                  <option value="Low">Low</option>
                  <option value="Medium">Medium </option>
                  <option value="High">High</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" >
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea" rows={3}
                  autoFocus required
                  onChange={(e) => setDescription(e.target.value)}
                  value={description}
                />
              </Form.Group>
              <Modal.Footer className='mt-3'>
                <Button variant="success" type="submit">
                  Create
                </Button>
              </Modal.Footer>
            </Form>
          </Modal.Body>
        </Modal>

        <Modal show={showNewTask2} onHide={handleNewModelClose2}>
          <Modal.Header closeButton>
            <Modal.Title>Update Task</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {errMsg != '' ?
              <Alert key="danger" variant="danger">
                {errMsg}
              </Alert>
              : ''}
            <Form noValidate validated={validatedNew2} onSubmit={handleNewSubmit2}>
              <Form.Group className="mb-3">
                <Form.Label>Priority </Form.Label>
                <Form.Select value={selectedTagValue2} onChange={handleTagSelectChange2}>
                  <option value="Low">Low</option>
                  <option value="Medium">Medium </option>
                  <option value="High">High</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" >
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea" rows={3}
                  autoFocus required
                  onChange={(e) => setDescription2(e.target.value)}
                  value={description2}
                />
              </Form.Group>
              <Modal.Footer className='mt-3'>
                <Button variant="danger" onClick={deleteTask}>
                  Delete
                </Button>
                <Button variant="success" type="submit">
                  Update
                </Button>
              </Modal.Footer>
            </Form>
          </Modal.Body>
        </Modal>
      </Container>
      {createPortal(
        <DragOverlay>
          {activeTask && (
            <TaskCard task={activeTask} updateTask={updateTask} />
          )}
        </DragOverlay>,
        document.body
      )}
      {inviteMode ? <InviteModel name={inviteName} inviteId={inviteBoardId} inviteMode={inviteMode} setInviteModel={setInviteModel}></InviteModel> : ''}
    </DndContext>
  );

  function getTimeAndDt() {
    const currentDate = new Date();
    const formattedTime = currentDate.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });

    // Format the date (DD MMM YY)
    const formattedDate = currentDate.toLocaleDateString('en-US', {
      day: '2-digit',
      month: 'short',
      year: '2-digit',
    });
    const formattedDateTime = `${formattedDate} ${formattedTime}`;
    return formattedDateTime;
  }

  function createTask(columnId) {
    let gid = generateId();
    const newTask = {
      id: gid,
      task_id: 1,
      order_id : '',
      tag: '',
      createdBy: getUserFullName(),
      createdDate: getTimeAndDt(),
      columnId,
      description: `Task ${tasks.length + 1}`,
    };
    setNewlyAddedTaskId(gid);
    setTasks([...tasks, newTask]);
  }

  function createTask1(columnId, tag, description) {
    let gid = generateId();
    const newTask = {
      id: gid,
      task_id: '',
      tag: tag,
      createdBy: getUserFullName(),
      createdDate: getTimeAndDt(),
      columnId,
      description: description,
    };
    console.log(tasks);
    console.log(newTask);
    setTasks([...tasks, newTask]);
  }


  function deleteTask() {
    const newTasks = tasks.filter((task) => task.id !== editTaskId);
    setTasks(newTasks);
    console.log(newTasks)
    handleNewModelClose2()
  }

  function updateTask(id, description, tag) {
    const newTasks = tasks.map((task) => {
      if (task.id !== id) return task;
      return { ...task, description, tag };
    });
    setTasks(newTasks);
  }


  function onDragStart(event) {
    if (event.active.data.current.type === "Column") {
      setActiveColumn(event.active.data.current.column);
      return;
    }

    if (event.active.data.current.type === "Task") {
      setActiveTask(event.active.data.current.task);
      return;
    }
  }

  function onDragEnd(event) {
    setActiveColumn(null);
    setActiveTask(null);

    const { active, over } = event;
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const isActiveAColumn = active.data.current.type === "Column";
    if (!isActiveAColumn) return;

    console.log("DRAG END");

    setColumns((columns) => {
      const activeColumnIndex = columns.findIndex((col) => col.id === activeId);

      const overColumnIndex = columns.findIndex((col) => col.id === overId);

      return arrayMove(columns, activeColumnIndex, overColumnIndex);
    });
  }

  function onDragOver(event) {
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    const isActiveATask = active.data.current.type === "Task";
    const isOverATask = over.data.current.type === "Task";

    if (!isActiveATask) return;

    if (isActiveATask && isOverATask) {
      setTasks((tasks) => {
        const activeIndex = tasks.findIndex((t) => t.id === activeId);
        const overIndex = tasks.findIndex((t) => t.id === overId);
        console.log(tasks);
        if (tasks[activeIndex].columnId !== tasks[overIndex].columnId) {
          tasks[activeIndex].columnId = tasks[overIndex].columnId;
          return arrayMove(tasks, activeIndex, overIndex - 1);
        }
        console.log(tasks);
        return arrayMove(tasks, activeIndex, overIndex);
      });
    }

    const isOverAColumn = over.data.current.type === "Column";

    if (isActiveATask && isOverAColumn) {
      setTasks((tasks) => {
        const activeIndex = tasks.findIndex((t) => t.id === activeId);
        console.log(tasks);
        tasks[activeIndex].columnId = overId;
        console.log("DROPPING TASK OVER COLUMN", { activeIndex });
        console.log(tasks);
        return arrayMove(tasks, activeIndex, activeIndex);
      });
    }
  }
}

function generateId() {
  return Math.floor(Math.random() * 10001);
}

export default KanbanBoard;

